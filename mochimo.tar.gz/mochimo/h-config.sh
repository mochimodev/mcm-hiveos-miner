#!/usr/bin/env bash
echo "Custom config not required at this time."
