#!/usr/bin/env bash

[[ `ps aux | grep "./mochimo-binary" | grep -v grep | wc -l` != 0 ]] &&
  echo -e "Mochimo miner is already running." &&
  exit 1

cd /hive/miners/custom/mochimo

./mochimo-binary -m wallet.dat
